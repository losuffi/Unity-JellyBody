﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace EffectL.Support.NodeSupport
{
    [Node(false,"循环-A类","Node")]
    public class TreeNodeItera:TreeNodeLogic
    {
        public override string GetId { get { return "循环-A类"; } }
        private TreeNodeResult res = TreeNodeResult.Done;
        protected internal override void Evaluator()
        {
            base.Evaluator();
        }

        protected internal override void NodeGUI()
        {

        }

        public override Node Create(Vector2 pos)
        {
            Node node = CreateInstance<TreeNodeItera>();
            node.Title = "循环A";
            node.rect = new Rect(pos, new Vector2(100, 80));
            node.CreateNodeInput("PreIn", "工作状态");
            node.CreateNodeOutput("Nextout", "工作状态");
            node.CreateNodeOutput("Forout", "工作状态",Side.Right);
            return node;

        }

        protected internal override TreeNodeResult OnUpdate()
        {
            Evaluator();
            getRes();
            if (res == TreeNodeResult.Break)
            {
                feedback = TreeNodeResult.Done;
                FeedBack();
                return TreeNodeResult.Done;
            }
            else if(res == TreeNodeResult.Running)
            {
                return TreeNodeResult.Running;
            }else if (res == TreeNodeResult.Done)
            {
                return TreeNodeResult.Running;
            }
            else
            {
                return TreeNodeResult.Failed;
            }
        }

        protected internal override void OnStart()
        {
            base.OnStart();
        }

        TreeNodeResult getRes()
        {
            res = TreeNodeResult.Running;
            var nodeOutput = outputKnobs.Find(T => T.Name.Equals("Forout"));
            foreach (var tarInput in nodeOutput.connections)
            {
                if(tarInput==null)
                    continue;
                var body = tarInput.Body as TreeNode;
                if (body.feedback == TreeNodeResult.Break)
                {
                    res= TreeNodeResult.Break;
                    return res;
                }
                if (body.feedback == TreeNodeResult.Running || body.feedback == TreeNodeResult.Idle)
                {
                    res = TreeNodeResult.Running;
                }
                if (body.feedback == TreeNodeResult.Done)
                {
                    body.feedback = TreeNodeResult.Start;
                    body.state = TreeNodeResult.Idle;
                    body.StateReset("Nextout");
                    body.state = TreeNodeResult.Start;
                }
            }
            return TreeNodeResult.Done;

        }

        //void CheckDone()
        //{
        //    var nodeOutput = outputKnobs.Find(T => T.Name.Equals("Forout"));
        //    foreach (NodeInput input in nodeOutput.connections)
        //    {
        //        if (input == null)
        //            continue;
        //        var body = input.Body as TreeNode;
        //        Debug.Log(body.feedback);
        //        if (body.feedback != TreeNodeResult.Done)
        //        {
        //            return;
        //        }
        //    }

        //    res = TreeNodeResult.Done;
        //}
        protected internal override void Start()
        {
            base.Start();
        }
    }
}
