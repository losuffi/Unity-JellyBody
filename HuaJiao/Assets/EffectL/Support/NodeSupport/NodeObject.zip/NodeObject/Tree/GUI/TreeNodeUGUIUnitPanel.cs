﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EffectL.Support.UnitSupport;
#if UNITY_EDITOR
using UnityEditor;

#endif
using UnityEngine;
using UnityEngine.Assertions;
using UnityEngine.UI;

namespace EffectL.Support.NodeSupport
{
    [Node(false, "Unit_UI内容输出", "Node")]
    public class TreeNodeUGUIUnitPanel : TreeNodeGUI
    {
        [SerializeField]
        private List<Text> texts=new List<Text>();
        [SerializeField]
        private List<Image> imgs = new List<Image>();
        private List<GlobalVariable> textV=new List<GlobalVariable>();
        private List<GlobalVariable> imgV=new List<GlobalVariable>();
        private List<bool> textB = new List<bool>();
        private List<bool> imgB = new List<bool>();
        public override string GetId { get { return "Unit_UI内容输出"; } }
        [SerializeField]
        private string seriName = string.Empty;
        private bool flag;
        protected internal override void Evaluator()
        {
            base.Evaluator();
        }

        protected internal override void NodeGUI()
        {
#if UNITY_EDITOR

            EffectUtility.FormatLabel("显示目标");
            DrawFillsLayout(variables[0]);
            EffectUtility.FormatLabel("数据来源:");
            DrawFillsLayout(variables[1]);
            if (variables[0].obj!=null&&variables[1].objMessage != null && variables[1].obj.GetType() == typeof(UnitBase))
            {
                if (!seriName.Equals(variables[1].objMessage))
                {
                    getContents((variables[0].obj as GameObject).transform);
                    initContent();
                    seriName = variables[1].objMessage;
                }
                else
                {
                    drawContent();
                }
            }

#endif
        }

        void drawContent()
        {
#if UNITY_EDITOR
            scrollVector2 = GUILayout.BeginScrollView(scrollVector2);
            for (int i = 0; i < texts.Count; i++)
            {
                textB[i] = EditorGUILayout.Toggle(textB[i]);
                EffectUtility.FormatLabel(texts[i].gameObject.name);
                if (textB[i])
                {
                    DrawUnitLayout(textV[i]);
                }
            }
            for (int j = 0; j < imgs.Count; j++)
            {
                imgB[j] = EditorGUILayout.Toggle(imgB[j]);
                EffectUtility.FormatLabel(imgs[j].gameObject.name);
                if (imgB[j])
                {
                    DrawUnitLayout(imgV[j]);
                }
            }
            GUILayout.EndScrollView();

#endif
        }
        public override Node Create(Vector2 pos)
        {
            TreeNode node = CreateInstance<TreeNodeUGUIUnitPanel>();
            node.Title = "Unit_UI内容输出";
            node.rect = new Rect(pos, new Vector2(180, 400));
            node.CreateNodeInput("PreIn", "工作状态");
            node.CreateNodeOutput("Nextout", "工作状态");
            node.CreateVariable();
            node.CreateVariable();
            return node;

        }

        protected internal override TreeNodeResult OnUpdate()
        {
            return TreeNodeResult.Running;
        }

        protected internal override void OnStart()
        {
            base.OnStart();
        }

        void initContent()
        {
            imgB.Clear();
            textB.Clear();
            textV.Clear();
            imgV.Clear();
            UnitBase tar = variables[1].obj as UnitBase;
            foreach (Text text in texts)
            {
                var v = new GlobalVariable();
                v.setRangeType(tar, "字符串", "真值", "实值");
                textV.Add(v);
                textB.Add(false);
            }
            foreach (Image img in imgs)
            {
                var v = new GlobalVariable();
                v.setRangeType(tar, "UISprite");
                imgV.Add(v);
                imgB.Add(false);
            }
        }
        void getContents(Transform obj)
        {
            texts.AddRange(obj.GetComponents<Text>());
            imgs.AddRange(obj.GetComponents<Image>());
            if (obj.childCount < 0)
            {
                return;
            }
            for (int i = 0; i < obj.childCount; i++)
            {
                getContents(obj.GetChild(i));
            }
        }

        protected internal override void Start()
        {
            variables[0].setRangeType(this, "ObjectUI");
            variables[1].setRangeType(this, "Unit");
            seriName = string.Empty;
            base.Start();
        }
    }
}
