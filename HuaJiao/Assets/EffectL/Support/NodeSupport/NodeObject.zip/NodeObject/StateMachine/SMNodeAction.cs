﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EffectL.Support.NodeSupport
{
    [Node(false, "动作", "NodeSelectPanel")]
    public class SMNodeAction:SMNode
    {
    }
}
